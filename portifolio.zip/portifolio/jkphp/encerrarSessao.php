<?php
	session_destroy();#destroy a sessao.
	header('location:index.html');# e volta para a pagina index.

?>